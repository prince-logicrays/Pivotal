var config = {
    "map": {
        "*": {
            "tradeInFormWidget": "Pivotal_TradeIn/js/trade-in-form-widget"
        } 
    }
};
